#import <Flutter/Flutter.h>

@interface BlueThermalPrinterPlugin : NSObject<FlutterPlugin>
@end
