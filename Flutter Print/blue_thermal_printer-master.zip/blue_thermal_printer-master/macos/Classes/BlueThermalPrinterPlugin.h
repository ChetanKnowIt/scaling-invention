#import <FlutterMacOS/FlutterMacOS.h>

@interface BlueThermalPrinterPlugin : NSObject<FlutterPlugin>
@end
