## 3.0.1

* opt format.

## 3.0.0

* null safety.

## 2.0.0

* adaptation flutter 1.23.13.

## 1.2.0

* fix ios library auto import bug.

## 1.1.0

* opt ios config.


## 1.0.1

* opt log.


## 1.0.0

* support ios print label(tsc command) and receipt(esc command).

## 0.1.2

* support print label(tsc command).

## 0.1.1

* support more gprinter devices.

## 0.1.0

* finished android features.

## 0.0.5

* fixed some bugs, opt readme.

## 0.0.4

* fixed some bugs.

## 0.0.3

* opt android print, add status display.

## 0.0.2

* add android print support.

## 0.0.1

* initial release.
* TODO: Describe initial release.

