## 0.2.1

- Update README and example

## 0.2.0

- New functions: boldOn/boldOff
- New functions: underlineOn/underlineOff
- New funtion: image
- iOS doesn't throw an exception anymore

## 0.1.1

- Using registerWith() to support the old pre-Flutter-1.12 Android projects

## 0.1.0

- Initial release
