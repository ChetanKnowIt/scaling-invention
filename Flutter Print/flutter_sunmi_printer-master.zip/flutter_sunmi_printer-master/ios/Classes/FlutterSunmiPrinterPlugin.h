#import <Flutter/Flutter.h>

@interface FlutterSunmiPrinterPlugin : NSObject<FlutterPlugin>
@end
