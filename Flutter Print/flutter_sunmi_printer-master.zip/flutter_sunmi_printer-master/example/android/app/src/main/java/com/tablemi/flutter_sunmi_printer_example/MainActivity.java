package com.tablemi.flutter_sunmi_printer_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
