//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import flutter_blue

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FlutterBluePlugin.register(with: registry.registrar(forPlugin: "FlutterBluePlugin"))
}
