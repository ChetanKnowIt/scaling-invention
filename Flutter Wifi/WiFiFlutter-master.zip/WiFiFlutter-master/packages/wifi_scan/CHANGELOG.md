## 0.2.1

 - **FEAT**: added `hasCapability` API (#258).

## 0.2.0+1

 - **FIX**: proper result if error after "ask permission" (#257).
 - **DOCS**: added link for iOS requirements.

## 0.2.0

> Note: This release has breaking changes.

 - **BREAKING** **REFACTOR**: not having separate "can" APIs for checks (#246).

## 0.1.0+3

 - **FIX**: example - stream toggle not working (#241).

## 0.1.0+2

 - **FIX**: example -`_getScannedResults` wrong implementation (#232).

## 0.1.0+1

 - **REFACTOR**: not using `StreamBuilder` but listening (#231).
 - **DOCS**: improvement (#230).
 - **DOCS**: fix doc link in plugin README.

## 0.1.0

 - **FEAT**: plugin added (#205).
