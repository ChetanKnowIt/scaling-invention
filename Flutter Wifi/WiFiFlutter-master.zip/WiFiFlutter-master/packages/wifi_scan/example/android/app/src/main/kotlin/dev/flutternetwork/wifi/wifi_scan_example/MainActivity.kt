package dev.flutternetwork.wifi.wifi_scan_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
