#import <Flutter/Flutter.h>

@interface WifiIotPlugin : NSObject <FlutterPlugin>
@end
